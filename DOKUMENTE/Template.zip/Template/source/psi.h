

int psiInit( void );
int psiTransfer( int32_t outdata, int32_t* indata );
